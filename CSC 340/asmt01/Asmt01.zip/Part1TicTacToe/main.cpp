#include <iostream>
#include <algorithm>
#include <string>

using namespace std;

bool isWon(char, char[][3]);
bool isDraw(char[][3]);
void displayBoard(char[][3]);
void makeAMove(char[][3], char);

int draw = 1;
//once there has been 9 moves and and no winner its a draw
bool isDraw(char board[][3]){
    if(draw == 10){
        return true;
    }
    return false;
}

bool isWon(char player, char board[][3]){
    //diagonal
    if(board[0][0] == player &&
       board[1][1] == player &&
       board[2][2] == player){
        return true;
    }
    //reverse diagonal
    if(board[0][2] == player &&
       board[1][1] == player &&
       board[2][0] == player){
        return true;
    }
    //vertical
    for(int i = 0; i < 3; i++){
        if(board[i][0] == player &&
           board[i][1] == player &&
           board[i][2] == player) {
            return true;
        }
        //horizontal
        if(board[0][i] == player &&
           board[1][i] == player &&
           board[2][i] == player) {
            return true;
        }
    }
    return false;
}

void displayBoard(char board[][3]){
    cout << "-------------" << endl;
    for(int i = 0; i < 3; i++) {
        cout <<"|";
        for(int j = 0; j < 3; j++) {
            cout << " " << board[i][j] << " |";
        }
        cout << endl << "-------------" << endl;
    }
}

void makeAMove(char board[][3], char player){
    int row, col;
    if(player == 'X') {
        cout << "Enter a row (0, 1, 2) for player X: " << endl;
        cin >> row;
        while (row > 2 || row < 0) {
            cout << "Not valid" << endl;
            cin >> row;
        }
        cout << "Enter a column (0, 1, 2) for player X: " << endl;
        cin >> col;
        while (col < 0 || col > 2) {
            cout << "Not valid" << endl;
            cin >> col;
        }
        while (board[row][col] == 'X' || board[row][col] == 'O') {
            cout << "This cell is already occupied. Try a different cell" << endl;
            cout << "Enter a row (0, 1, 2) for player X: " << endl;
            cin >> row;
            while (row > 2 || row < 0) {
                cout << "Not valid" << endl;
                cin >> row;
            }
            cout << "Enter a column (0, 1, 2) for player X: " << endl;
            cin >> col;
            while (col < 0 || col > 2) {
                cout << "Not valid" << endl;
                cin >> col;
            }
        }
    }
    else if(player == 'O') {
        cout << "Enter a row (0, 1, 2) for player O: " << endl;
        cin >> row;
        while (row > 2 || row < 0) {
            cout << "Not valid" << endl;
            cin >> row;
        }
        cout << "Enter a column (0, 1, 2) for player O: " << endl;
        cin >> col;
        while (col < 0 || col > 2) {
            cout << "Not valid" << endl;
            cin >> col;
        }
        while (board[row][col] == 'X' || board[row][col] == 'O') {
            cout << "This cell is already occupied. Try a different cell" << endl;
            cout << "Enter a row (0, 1, 2) for player O: " << endl;
            cin >> row;
            while (row > 2 || row < 0) {
                cout << "Not valid" << endl;
                cin >> row;
            }
            cout << "Enter a column (0, 1, 2) for player O: " << endl;
            cin >> col;
            while (col < 0 || col > 2) {
                cout << "Not valid" << endl;
                cin >> col;
            }
        }
    }
    else{
        cout << player << " Not in the game." << endl;
        exit(0);
    }
    board[row][col] = player;
    draw++;
}



int main() {
    //
    //	PLEASE DO NOT CHANGE main()
    //
    char board[3][3] = { { ' ', ' ', ' ' },{ ' ', ' ', ' ' },{ ' ', ' ', ' ' } };
    displayBoard(board);



    while (true) {
        // The first player makes a move
        makeAMove(board, 'X');
        displayBoard(board);
        if (isWon('X', board)) {
            cout << "X player won" << endl;
            exit(0);
        }
        else if (isDraw(board)) {
            cout << "No winner" << endl;
            exit(0);
        }

        // The second player makes a move
        makeAMove(board, 'O');
        displayBoard(board);

        if (isWon('O', board)) {
            cout << "O player won" << endl;
            exit(0);
        }
        else if (isDraw(board)) {
            cout << "No winner" << endl;
            exit(0);
        }
    }

    return 0;
}