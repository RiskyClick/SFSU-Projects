/*
Keith Rich
Professor Duc Ta
CSC340.01
6/28/2018
 */
#include <iostream>
#include <fstream>
#include <vector>
#include <string>
#include <algorithm>
#include <sstream>


using namespace std;

void search(vector<string> dictionary, string query){
    int found = 0;
    vector <string> tokens;
    stringstream check1(query);
    string intermediate, notFound("<Not found.>");
    string noun("noun"), verb("verb"), adjective("adjective");
    string modify, begin(" ["), end("] : ");
    //split the query into seprate strings
    while(getline(check1, intermediate, ' ')) {
        tokens.push_back(intermediate);
    }
    if(tokens.size() > 2 || tokens.size() < 1){
        cout << "\t <Please enter a search key (and a part of speech).>" << endl;
        return;
    }
    if(tokens.size() == 2){
        if(tokens[1].compare(noun) != 0 && tokens[1].compare(verb) != 0 && tokens[1].compare(adjective) != 0) {
            cout << "\t <2nd argument must be a part of speech.>" << endl;
            return;
        }
        //add [] around noun, verb, or adj's then convert the the hole string to lowercase
        tokens[1].insert(0, begin);
        tokens[1].insert(tokens[1].length(), end);
        modify = tokens[0] + tokens[1];
        transform(modify.begin(), modify.end(), modify.begin(), ::tolower);
        for(int i = 0; i < dictionary.size(); i++){
            if(dictionary[i].find(modify) == 0){
                found++;
                cout << "\t " << dictionary[i] << endl;
            }
        }
    }
    if(tokens.size() == 1){
        //same here by converting to lowercase
        transform(tokens[0].begin(), tokens[0].end(), tokens[0].begin(), ::tolower);
        // add a space at the end of the first word to prevent things like bookable from being matched with just book
        tokens[0].insert(tokens[0].length(), " ");
        for(int i = 0; i < dictionary.size(); i++){
            if(dictionary[i].find(tokens[0]) == 0){
                found++;
                cout << "\t " << dictionary[i] << endl;
            }
        }
    }
    if(found == 0){
        cout << "\t " << notFound << endl;
    }
}

//purpose is to format the givin txt file into a workable verctor to meet assingment formatting
vector<string> trim(vector<string> toTrim) {
    vector<string> separated;
    string begin(" ["), end("] : ");
    //used the '.' to further sperate out the definitions
    for (int i = 0; i < toTrim.size(); i++) {
        string delimiter = (".");
        size_t pos = 0;
        string token;
        //there was a missing period on the csc340 so i added one to help with the delimiter
        if (toTrim[i].find("more|noun") != std::string::npos) {
            toTrim[i].insert(separated[i].find("more|noun") + 58, delimiter);
        }
        //the actual tokenizer for the '.'
        while ((pos = toTrim[i].find(delimiter)) != std::string::npos) {
            token = toTrim[i].substr(0, pos + 1);
            separated.push_back(token);
            toTrim[i].erase(0, pos + delimiter.length());
        }
    }
    //remove all the things that are not needed in the output as well as wrap noun, verb and adj in []
    for (int i = 0; i < separated.size(); i++) {
        separated[i].erase(std::remove(separated[i].begin(), separated[i].end(), '='), separated[i].end());
        separated[i].erase(std::remove(separated[i].begin(), separated[i].end(), '>'), separated[i].end());
        separated[i].erase(std::remove(separated[i].begin(), separated[i].end(), '|'), separated[i].end());
        if (separated[i].find("noun") != std::string::npos) {
            separated[i].insert(separated[i].find("noun"), begin);
            separated[i].insert(separated[i].find("noun") + 4, end);
        }
        if (separated[i].find("verb") != std::string::npos) {
            separated[i].insert(separated[i].find("verb"), begin);
            separated[i].insert(separated[i].find("verb") + 4, end);
        }
        if (separated[i].find("adjective") != std::string::npos) {
            separated[i].insert(separated[i].find("adjective"), begin);
            separated[i].insert(separated[i].find("adjective") + 9, end);
        }
        //this assings the lost definitions back on to the items. ex, adds book to the front of the definition for book verb.
        if (separated[i].find(" ") == 0) {
            string buffer = separated[i - 1].substr(0, separated[i - 1].find_first_of(' '));
            separated[i].insert(0, buffer);
        }
    }
    return separated;
}

int main() {
    vector<string> toTrim, separated;
    string line, query, halt("!Q");
    cout << "! Opening data file ... ./Data.CS.SFSU.txt" << endl;
    ifstream myfile("C:\\Users\\Keith\\Documents\\CSC 340\\asmt01\\Data.CS.SFSU.txt");
    if (myfile.is_open()) {
        cout << "! Loading data..." << endl;
        // here we read the file and push back each line of the file into a vector
        while (getline(myfile, line)) {
            toTrim.push_back(line);
        }
        cout << "! Loading completed..." << endl;
        cout << "! Closing data file ... ./Data.CS.SFSU.txt" << endl << endl;
        //part 1: Opens and closes the included “Data.CS.SFSU.txt” only once per run
        myfile.close();
    } else cout << "Unable to open file" << endl;
    //function call for removing and formatting the vector
    //part 2: Finishes loading data from “Data.CS.SFSU.txt” into its dictionary data structure(s) and closes the file before starting
    //to interact with users.
    separated = trim(toTrim);
    cout << "----DICTIONARY 340 C++----" << endl << endl;
    cout << "Search: " << endl;
    getline(cin, query);
    while(query != halt){
        cout << "\t|" << endl;
        //function call for search
        //Part 3: Produces identical output. The complete output is included in the provide ZIP file: Part3_Run..txt
        search(separated, query);
        cout << "\t|" << endl;
        cout << "Search: " << endl;
        getline(cin, query);
    }
    return 0;
}
